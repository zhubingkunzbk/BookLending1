package bookLendingClient.model;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;

import bookLending.Main;
import bookLendingServer.model.RedBlackTree;
import bookLendingServer.model.Users;

public class Util {
	private static BplusTree<Long,Book> allBook = new BplusTree<>(10);
	private static RedBlackTree<String, LinkedList<Long>> bookName = new RedBlackTree<>();
	private static RedBlackTree<String, LinkedList<Long>> authorName = new RedBlackTree<>();
	private static Users users = Users.getInstance();
	public static BplusTree<Long,Book> getBooks() {
		return allBook;
	}
	public static RedBlackTree<String, LinkedList<Long>> getBookName() {
		return bookName;
	}

	public static RedBlackTree<String, LinkedList<Long>> getAuthorName() {
		return authorName;
	}

	public static void initAllBook() {
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream(Main.class.getResource("allBook.XML").getPath()));
			Book book = null;
			while(true) {
				book = (Book)ois.readObject();
				if(book == null) {
					break;
				}
				if(allBook.get(book.getISBN()) == null) {
					LinkedList<Long> list = bookName.get(book.getName());
					if(list == null) {
						bookName.add(book.getName(), new LinkedList<>());
						list = bookName.get(book.getName());
					}
					list.add(book.getISBN());
					list = authorName.get(book.getAuthor());
					if(list == null) {
						authorName.add(book.getAuthor(), new LinkedList<>());
						list = authorName.get(book.getAuthor());
					}
					list.add(book.getISBN());
					
					allBook.add(book.getISBN(), book);
				}
			}
			try {
				ois = new ObjectInputStream(new FileInputStream(Main.class.getResource("allUser.XML").getPath()));
				User user = null;
				while(true) {
					user = (User)ois.readObject();
					if(user == null) {
						break;
					}
					users.addUser(user);
				}
			}catch(EOFException e) {
			}
			System.out.println("反序列化完成");
		} catch(ClassNotFoundException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				ois.close();
			} catch (IOException e) {
				e.printStackTrace();
			} catch (NullPointerException e) {
				e.printStackTrace();
			}
		}
	}
	public static void finaly() {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			@Override
			public void run() {
				ObjectOutputStream oos = null;
				try {
					oos = new ObjectOutputStream(new FileOutputStream(Main.class.getResource("allBook.XML").getPath()));
					Iterator<Book> it = allBook.iterator();
					while(it.hasNext()) {
						oos.writeObject(it.next());
					}
					oos.writeObject(null);
					System.out.println("书籍序列化完成");
					oos = new ObjectOutputStream(new FileOutputStream(Main.class.getResource("allUser.XML").getPath()));
					Iterator<User> it1 = users.iterator();
					while(it1.hasNext()) {
						oos.writeObject(it1.next());
					}
					oos.writeObject(null);
					System.out.println("用户序列化完成");
					System.out.println("进程中断");
					
				}catch(IOException e){
					e.printStackTrace();
				}finally {
					try {
						oos.close();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (NullPointerException e) {
						e.printStackTrace();
					}
				}
			}
		}));
	}
}
