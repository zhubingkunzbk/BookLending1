package bookLendingClient.model;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;


public class Server {
	private static Server instance = null;
	private ServerSocket serverSocket;
	private Socket clientSocket;
	private LinkedList<ClientSocketThread> threadList;
	private Server() {
		try {
			this.serverSocket = new ServerSocket(8080);
		} catch (IOException e) {
			e.printStackTrace();
		}
		this.threadList = new LinkedList<>();
	}
	public static Server getInstance() {
		if(instance == null) {
			instance = new Server();
		}
		return instance;
	}
	/**
	 * 获得客户机数量
	 * @return 线程列表长度
	 */
	public int getClientNum() {
		return this.threadList.size();
	}
	
	/**
	 * 监听客户端连接
	 * @return 新的客户端的连接
	 */
	public Socket getNewConnection(){
		//监听客户端连接，如果连接成功返回对应客户端Socket引用，否则返回空代表发生异常
		Socket clientSocket = null; 
		try {
			clientSocket = this.serverSocket.accept();//阻塞方法，等待客户端连接	
		} catch (IOException e) {
			return null;
		}
		return clientSocket;
	}
	/**
	 * 向线程列表添加新线程
	 * @param clientSocketThread 准备被添加的新线程对象
	 */
	public void addThread(ClientSocketThread clientSocketThread) {
		for(int i = 0;i < this.threadList.size();i++) {
			if(!this.threadList.get(i).isConnect()) {
				this.threadList.remove(i);
				i--;
			}
		}
		this.threadList.add(clientSocketThread);
	}
}
