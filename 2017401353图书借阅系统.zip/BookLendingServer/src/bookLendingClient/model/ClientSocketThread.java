package bookLendingClient.model;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Iterator;

import bookLendingServer.model.Users;

public class ClientSocketThread extends Thread implements Comparable<ClientSocketThread>{
	private boolean isConnect;
	//该线程所需要服务的客户端
	private Socket clientSocket;
	private Users users = Users.getInstance();
	//io相关
	private DataInputStream Is;
	private DataOutputStream dos;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	public ClientSocketThread(Socket clientSocket){
		//true为已连接，false需要断开
		this.isConnect = true;
		//引用传入的客户端对象
		this.clientSocket = clientSocket;
	}
	public boolean isConnect() {
		return this.isConnect;
	}
	@Override
	public void run() {
		while(this.isConnect) {
			String request = receive();
			try {
				parsingRequest(request);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			if(dos != null)
				this.dos.close();
			if(Is != null)
				this.Is.close();
			if(oos != null)
				this.oos.close();
			if(ois != null)
				this.ois.close();
			this.clientSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	private void parsingRequest(String request) throws Exception{
		if(request.equals("verificationUserName")) {
			verificationUserName(receive());
		}else if(request.equals("register")) {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			addUser((User)ois.readObject());
		}else if(request.equals("login")) {
			handleLogin();
		}else if(request.equals("getList")) {
			String i = receive();
			int pageNum = Integer.parseInt(i);
			handleList(pageNum);
		}else if(request.equals("search")) {
			handleSearch();
		}else if(request.equals("changeUser")) {
			handleChangeUser();
		}else if(request.equals("lending")) {
			handleLending();
		}else if(request.equals("giveBack")) {
			handleGiveBack();
		}else if(request.equals("getBook")) {
			long isbn = Long.parseLong(receive());
			send(Util.getBooks().get(isbn));
		}else if(request.equals("changeBook")) {
			handleChangeBook();
		}else if(request.equals("removeBook")) {
			handleRemoveBook();
		}else if(request.equals("addBook")) {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			Book book = (Book)ois.readObject();
			if(Util.getBooks().get(book.getISBN()) == null) {
				Util.getBooks().add(book.getISBN(), book);
				if(Util.getAuthorName().get(book.getAuthor()) == null) {
					Util.getAuthorName().add(book.getAuthor(), new LinkedList<Long>());
				}
				Util.getAuthorName().get(book.getAuthor()).add(book.getISBN());
				if(Util.getBookName().get(book.getName()) == null) {
					Util.getBookName().add(book.getName(), new LinkedList<Long>());
				}
				Util.getBookName().get(book.getName()).add(book.getISBN());
			}
			
		}
		
		
		else if(request.equals("quit")) {
			this.isConnect = false;
		}
	}
	private void handleRemoveBook() {
		
		String rearISBN = receive();
		try {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			Book removeBook = (Book)ois.readObject();
			Book nextBook = Util.getBooks().getNext(Long.parseLong(rearISBN));
			Util.getBooks().remove(removeBook.getISBN());
			Util.getAuthorName().get(removeBook.getAuthor()).remove(removeBook.getISBN());
			Util.getBookName().get(removeBook.getName()).remove(removeBook.getISBN());
			send(nextBook);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	private void handleChangeBook() {
		try {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			Book changeBook = (Book)ois.readObject();
			Book book = Util.getBooks().get(changeBook.getISBN());
			Util.getBookName().get(book.getName()).remove(changeBook.getISBN());
			Util.getAuthorName().get(book.getAuthor()).remove(changeBook.getISBN());
			book.setName(changeBook.getName());
			book.setAuthor(changeBook.getAuthor());
			book.setPress(changeBook.getPress());
			book.setPrice(changeBook.getPrice());
			book.setNum(changeBook.getNum());
			Util.getAuthorName().get(book.getAuthor()).add(book.getISBN());
			Util.getBookName().get(book.getName()).add(book.getISBN());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	private void handleGiveBack() {
		try {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			LinkedList<Object> list = (LinkedList<Object>) ois.readObject();
			User listUser = (User) list.get(0);
			LendingBook listLendBook = (LendingBook) list.get(1);
			Student user = (Student)users.get(listUser.getUserName());
			user.getLendingList().remove(listLendBook);
			Book book = Util.getBooks().get(listLendBook.getBook().getISBN());
			if(book.getBorrowingQueue().getPos(user) != 0) {
				book.getBorrowingQueue().remove(user);
			}else {
				book.setNum(book.getNum() + 1);
				if(book.getBorrowingQueue().size() != 0) {
					book.setNum(book.getNum() - 1);
					book.getBorrowingQueue().pop();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
	}
	private void handleLending() {
		try {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			LinkedList<Object> list = (LinkedList<Object>) ois.readObject();
			Student user = (Student)users.get(((User)list.get(0)).getUserName());
			Book book = Util.getBooks().get(Long.valueOf(((Book)list.get(1)).getISBN()));
			LendingBook lendingBook = (LendingBook)list.get(2);
			user.getLendingList().add(lendingBook);
			if(book.getNum() == 0) {
				book.getBorrowingQueue().push(user);
			}else {
				book.setNum(book.getNum() - 1);
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		
		
	}
	synchronized private void handleChangeUser() {
		try {
			ois = new ObjectInputStream(new BufferedInputStream(clientSocket.getInputStream()));
			User user = (User)ois.readObject();
			User serverUser = users.get(user.getUserName());
			serverUser.setPassword(user.getPassword());
			serverUser.setPhoneNumber(user.getPhoneNumber());
			serverUser.setRealName(user.getRealName());
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}		
		
	}
	private void handleSearch() {
		String type = receive();
		String key = receive();
		LinkedList<Book> results = new LinkedList<>();
		if(type.equals("ISBN")) {
			results.add(Util.getBooks().get(Long.parseLong(key)));
		}else if(type.equals("bookName")) {
			LinkedList<Long> temp = Util.getBookName().get(key);
			if(temp != null)
				for(long ele:temp) {
					results.add(Util.getBooks().get(ele));
				}
		}else {
			LinkedList<Long> temp = Util.getAuthorName().get(key);
			if(temp != null)
				for(long ele:temp) {
					results.add(Util.getBooks().get(ele));
				}
		}
		send(results);
		
	}
	private void handleList(int pageNum) {
		int startPos = (pageNum - 1) * 19;
		LinkedList<Book> list = new LinkedList<>();
		BplusTree<Long,Book> tree = Util.getBooks();
		Iterator<Book> it = tree.iterator();
		while(it.hasNext() && startPos != 0) {
			it.next();
			startPos--;
		}
		int maxNum = 0;
		while(it.hasNext() && maxNum < 19) {
			list.add(it.next());
			maxNum++;
		}
		send(list);
	}
	private void handleLogin() {
		String userName = receive();
		String password = receive();
		User user = users.get(userName);
		if(user == null) {
			send("noUser");
		}else if(!user.getPassword().equals(password)) {
			send("passwordError");
		}else {
			send("ok");
			send(user);
		}
	}
	private void addUser(User user) {
		users.addUser(user);
		
	}
	private void verificationUserName(String userName) {
		User user = users.get(userName);
		if(user != null) {
			send("exist");
		}else {
			send("noExist");
		}
		
	}
	private void send(String msg) {
		try {
			dos = new DataOutputStream(this.clientSocket.getOutputStream());
			dos.writeUTF(msg);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	private void send(Object obj) {
		try {
			oos = new ObjectOutputStream(this.clientSocket.getOutputStream());
			oos.writeObject(obj);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	private String receive() {
		try {
			Is = new DataInputStream(this.clientSocket.getInputStream());
			String msg = Is.readUTF();
			return msg;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}
	@Override
	public int compareTo(ClientSocketThread arg0) {
		return 0;
	}
	

}
