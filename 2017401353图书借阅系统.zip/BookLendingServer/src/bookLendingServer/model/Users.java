package bookLendingServer.model;

import java.util.Iterator;

import bookLendingClient.model.Book;
import bookLendingClient.model.User;

public class Users {
	private RedBlackTree<String, User> users;
	private static Users instance = null;
	private Users() {
		this.users = new RedBlackTree<>();
	}
	synchronized public static Users getInstance() {
		if(instance == null) {
			instance = new Users();
		}
		return instance;
	}
	synchronized public void addUser(User user) {
		this.users.add(user.getUserName(), user);
	}
	synchronized public User get(String userName) {
		return this.users.get(userName);
	}
	public Iterator<User> iterator() {
		
		return this.users.iterator();
	}
	
}
