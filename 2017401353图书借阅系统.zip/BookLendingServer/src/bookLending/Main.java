package bookLending;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Random;

import bookLendingClient.model.Book;
import bookLendingClient.model.ClientSocketThread;
import bookLendingClient.model.Server;
import bookLendingClient.model.Student;
import bookLendingClient.model.User;
import bookLendingClient.model.Util;

public class Main {
	
    public static void main(String[] args) {  
    	Util.finaly();
    	//init();
        Util.initAllBook();
        Server server = Server.getInstance();
		while(true) {
			
			//监听连接，如果监听出现异常则重新监听
			Socket clientSocket = server.getNewConnection();
			if(clientSocket == null) {
				continue;
			}
			//以新的连接套接字创建客户端线程对象
			ClientSocketThread clientSocketThread = new ClientSocketThread(clientSocket);
			//将新线程加入到线程列表
			server.addThread(clientSocketThread);
			System.out.println("连接了一台客户机" + clientSocket);
			System.out.println("当前连接" + server.getClientNum() + "台客户机");
			//启动线程
			clientSocketThread.start();
		}
    }

	private static void init() {
		try {
			String line;
			int i = 1;
			ObjectOutputStream oos = null;
			oos = new ObjectOutputStream(new FileOutputStream(Main.class.getResource("allBook.XML").getPath()));
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\Users\\46203\\Desktop\\book_info.txt")));
			while((line = br.readLine()) != null) {
				System.out.println(line);
				String[] s = line.split(" ");
				Double price = 0.0;
				try {
					price = Double.parseDouble(s[3].split(":")[1].replaceAll("[^0-9|.]", ""));
				}catch(NumberFormatException e) { 
					continue;
				}
				Book book = new Book(Long.parseLong(s[4].split(":")[1].replaceAll("[^0-9]", "")), s[0].split(":")[1], s[1].split(":")[1], s[2].split(":")[1], price, new Random().nextInt(50));

				try {
					oos.writeObject(book);
				}catch(IOException e){
					e.printStackTrace();
				}
			}
			oos.writeObject(null);
			oos.close();
		
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}  

}
